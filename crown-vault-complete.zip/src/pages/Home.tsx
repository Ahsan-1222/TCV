import { Hero } from '../components/home/Hero';
import { FeaturedCategories } from '../components/home/FeaturedCategories';
import { BrandStory } from '../components/home/BrandStory';
import { Testimonials } from '../components/home/Testimonials';
import { ProductGrid } from '../components/product/ProductGrid';
import { useProducts } from '../hooks/useProducts';
import { Link } from 'react-router-dom';

export const Home = () => {
  const products = useProducts();
  const featured = products.filter(p => p.featured).slice(0, 8);
  const bestSellers = products.filter(p => p.bestSeller);

  return (
    <div>
      <Hero />
      <FeaturedCategories />

      <section className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-10">
        <ProductGrid products={featured} title="Featured Fragrances" />
        <div className="mt-8 text-center">
          <Link to="/shop" className="inline-flex border border-black px-8 py-3 text-[11px] tracking-[0.2em] uppercase hover:bg-black hover:text-white transition-colors">View All Products</Link>
        </div>
      </section>

      {/* Promo Banner like Rumi Trends */}
      <section className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-6">
        <div className="grid md:grid-cols-2 gap-[1px] bg-neutral-200 border border-neutral-200">
          <div className="bg-[#0A0A0A] text-white p-10 md:p-12 flex flex-col justify-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-crown-gold/10 rounded-full blur-3xl"></div>
            <div className="text-crown-gold text-[11px] tracking-[0.3em] uppercase mb-4">Bundle Offer</div>
            <h3 className="font-display text-[28px] md:text-[36px] leading-none">Pack of 3 — 50ML<br /><span className="italic font-light text-white/60">ROOH Signature Trio</span></h3>
            <p className="text-[13px] text-white/60 mt-4 max-w-[360px]">AQUA + AVANT + NOIR. Perfect gift box integration with watch collection. COD available.</p>
            <div className="mt-6 flex items-center gap-3">
              <span className="text-2xl font-display">Rs. 6,950</span>
              <span className="line-through opacity-40 text-sm">Rs. 12,000</span>
              <span className="bg-crown-gold text-black text-[10px] px-2 py-1 uppercase tracking-widest">-42%</span>
            </div>
            <Link to="/shop" className="mt-8 bg-white text-black px-6 py-3 text-[11px] tracking-[0.2em] uppercase w-fit hover:bg-crown-gold hover:text-white transition-colors">Shop Bundle</Link>
          </div>
          <div className="bg-white p-0 relative aspect-[4/3] md:aspect-auto overflow-hidden">
            <img src={`/assets/products/${encodeURIComponent('WhatsApp Image 2026-07-17 at 8.30.52 PM (4).jpeg')}`} alt="Bundle" className="w-full h-full object-cover" />
          </div>
        </div>
      </section>

      <section className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-10">
        <ProductGrid products={bestSellers} title="Best Sellers" />
      </section>

      <BrandStory />
      <Testimonials />
    </div>
  );
};
