import { useState } from 'react';
import { products as initialProducts } from '../../data/products';
import type { Product } from '../../types';
import { formatPrice } from '../../lib/utils';
import { Plus, Edit3, Trash2, Upload } from 'lucide-react';

export const ProductsAdmin = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('tcv_admin_products');
    return saved ? JSON.parse(saved) : initialProducts;
  });
  const [editing, setEditing] = useState<Product | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<Partial<Product>>({
    name: '', price: 0, stock: 0, category: 'perfume', shortDescription: '', description: '', featured: false,
    sku: '', tags: []
  });

  const persist = (list: Product[]) => {
    localStorage.setItem('tcv_admin_products', JSON.stringify(list));
    // Also update main product list that appears on site by updating localStorage that Shop reads? For demo we keep separate, but we sync to tcv_products
    localStorage.setItem('tcv_products', JSON.stringify(list));
  };

  const handleSave = () => {
    if (!form.name) return alert('Name required');
    const newProduct: Product = {
      id: editing?.id || Math.random().toString(36).slice(2,9),
      sku: form.sku || `SKU-${Date.now()}`,
      name: form.name!,
      slug: form.name!.toLowerCase().replace(/\s+/g,'-'),
      description: form.description || '',
      shortDescription: form.shortDescription || '',
      category: (form.category as any) || 'perfume',
      price: Number(form.price) || 0,
      stock: Number(form.stock) || 0,
      images: editing?.images || [{ url: `https://picsum.photos/seed/${Date.now()}/600/800`, alt: form.name!, isMain: true }],
      tags: form.tags || [],
      featured: !!form.featured,
      rating: editing?.rating || 4.8,
      reviewCount: editing?.reviewCount || 0,
      reviews: editing?.reviews || [],
      createdAt: editing?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    let list;
    if (editing) list = products.map(p=>p.id===editing.id?{...newProduct, id: editing.id}:p);
    else list = [newProduct, ...products];
    setProducts(list);
    persist(list);
    setShowForm(false);
    setEditing(null);
  };

  const handleDelete = (id: string) => {
    if (!confirm('Delete product?')) return;
    const list = products.filter(p=>p.id!==id);
    setProducts(list);
    persist(list);
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-[28px]">Manage Products — {products.length}</h1>
        <button onClick={()=>{setEditing(null); setForm({name:'',price:0,stock:10,category:'perfume',shortDescription:'',description:'',featured:false,sku:'',tags:[]}); setShowForm(true);}} className="bg-black text-white px-5 py-2.5 text-[11px] tracking-widest uppercase flex items-center gap-2"><Plus size={14}/>Add Product</button>
      </div>

      {showForm && (
        <div className="bg-white border p-6 mt-6 grid md:grid-cols-2 gap-4">
          <h3 className="md:col-span-2 font-display text-lg">{editing?'Edit Product':'Add New Product — Firebase Storage Ready'}</h3>
          <input placeholder="Name (e.g. ROOH..." value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="border px-4 py-2.5 text-[13px]" />
          <input placeholder="SKU" value={form.sku} onChange={e=>setForm({...form,sku:e.target.value})} className="border px-4 py-2.5 text-[13px]" />
          <input type="number" placeholder="Price" value={form.price} onChange={e=>setForm({...form,price:Number(e.target.value)})} className="border px-4 py-2.5 text-[13px]" />
          <input type="number" placeholder="Stock" value={form.stock} onChange={e=>setForm({...form,stock:Number(e.target.value)})} className="border px-4 py-2.5 text-[13px]" />
          <select value={form.category} onChange={e=>setForm({...form,category:e.target.value as any})} className="border px-4 py-2.5 text-[13px]">
            <option value="perfume">Perfume</option><option value="bags">Bags</option><option value="jewellery">Jewellery</option><option value="watches">Watches</option>
          </select>
          <label className="flex items-center gap-2 text-[12px]"><input type="checkbox" checked={!!form.featured} onChange={e=>setForm({...form,featured:e.target.checked})} /> Featured</label>
          <input placeholder="Short Description" value={form.shortDescription} onChange={e=>setForm({...form,shortDescription:e.target.value})} className="border px-4 py-2.5 text-[13px] md:col-span-2" />
          <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} className="border px-4 py-2.5 text-[13px] md:col-span-2" rows={3} />
          <div className="md:col-span-2 flex gap-2">
            <button onClick={handleSave} className="bg-black text-white px-6 py-2.5 text-[11px] tracking-widest uppercase">Save — Auto appears on website</button>
            <button onClick={()=>setShowForm(false)} className="border px-6 py-2.5 text-[11px] tracking-widest uppercase">Cancel</button>
            <span className="ml-auto flex items-center gap-2 text-[11px] opacity-50"><Upload size={14}/> Multiple images upload ready for Firebase Storage</span>
          </div>
        </div>
      )}

      <div className="bg-white border mt-6 overflow-auto">
        <table className="w-full text-[12px]">
          <thead className="bg-[#F8F6F3] text-[11px] uppercase tracking-widest"><tr><th className="text-left p-3">Product</th><th className="text-left p-3">Category</th><th className="text-left p-3">Price</th><th className="text-left p-3">Stock</th><th className="text-left p-3">Featured</th><th className="text-right p-3">Actions</th></tr></thead>
          <tbody>
            {products.map(p=>(
              <tr key={p.id} className="border-t">
                <td className="p-3 flex items-center gap-2"><img src={(p.images.find(i=>i.isMain)||p.images[0]).url} className="w-8 h-10 object-cover bg-[#F8F6F3]" /><span className="font-medium uppercase">{p.name}</span></td>
                <td className="p-3 capitalize">{p.category}</td>
                <td className="p-3">{formatPrice(p.price)}</td>
                <td className="p-3">{p.stock}</td>
                <td className="p-3">{p.featured?'Yes':'No'}</td>
                <td className="p-3 text-right flex gap-2 justify-end">
                  <button onClick={()=>{setEditing(p); setForm(p); setShowForm(true);}} className="w-7 h-7 border flex items-center justify-center hover:bg-black hover:text-white"><Edit3 size={12}/></button>
                  <button onClick={()=>handleDelete(p.id)} className="w-7 h-7 border flex items-center justify-center hover:bg-red-600 hover:text-white"><Trash2 size={12}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
