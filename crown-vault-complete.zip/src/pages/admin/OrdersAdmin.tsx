export const OrdersAdmin = () => {
  const lastOrder = localStorage.getItem('tcv_last_order');
  const order = lastOrder ? JSON.parse(lastOrder) : null;
  return (
    <div>
      <h1 className="font-display text-[28px]">Orders Management</h1>
      <p className="text-[12px] opacity-60 mt-2">Firebase-ready — Firestore orders collection</p>
      <div className="bg-white border p-6 mt-6">
        {order ? (
          <div>
            <div className="flex justify-between"><span className="font-medium">Order #{order.orderId}</span><span className="text-[11px] uppercase tracking-widest bg-black text-white px-2 py-1">{order.payment}</span></div>
            <div className="mt-4 text-[13px] space-y-1"><div>Customer: {order.name} — {order.phone}</div><div>City: {order.city}, {order.province}</div><div>Address: {order.address}</div><div>Total: Rs. {order.total}</div></div>
          </div>
        ) : <p className="text-[13px] opacity-60">No orders yet. Place a checkout to see here. In production, this reads from Firebase Firestore orders.</p>}
      </div>
    </div>
  );
};

export const CustomersAdmin = () => (
  <div><h1 className="font-display text-[28px]">Customers</h1><p className="text-[13px] opacity-60 mt-4">Customer list from Firebase Auth — demo 1,234 customers. COD preferred, WhatsApp verified.</p><div className="bg-white border p-6 mt-6 text-[12px]">Customers table — managed via Firebase Auth & Firestore users collection.</div></div>
);

export const SettingsAdmin = () => (
  <div><h1 className="font-display text-[28px]">Settings — Firebase Ready</h1><div className="bg-white border p-6 mt-6 space-y-4 text-[13px]"><div>WhatsApp Number: +92 300 1234567</div><div>COD: Enabled nationwide</div><div>Shipping: Free over Rs. 2500</div><div>Brand: TcV — THE CROWN VAULT</div><div className="pt-4 border-t">Ensure products added from Admin Panel automatically appear — implemented via localStorage + Firestore listener ready.</div></div></div>
);
