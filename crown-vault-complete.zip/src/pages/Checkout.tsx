import { useCart } from '../context/CartContext';
import { formatPrice } from '../lib/utils';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export const Checkout = () => {
  const { items, total, clearCart } = useCart();
  const [form, setForm] = useState({ name: '', phone: '', email: '', address: '', city: '', province: 'Punjab' });
  const [payment, setPayment] = useState<'cod' | 'whatsapp'>('cod');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, push to Firebase Firestore orders collection
    const orderId = 'TCV-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    localStorage.setItem('tcv_last_order', JSON.stringify({ orderId, items, total, ...form, payment }));
    clearCart();
    navigate(`/checkout/success?order=${orderId}`);
  };

  if (items.length === 0) return <div className="max-w-[1600px] mx-auto px-12 py-20"><Link to="/shop">Cart empty, continue shopping</Link></div>;

  const shipping = total > 2500 ? 0 : 199;

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-12 grid lg:grid-cols-[1fr_420px] gap-12">
      <div>
        <h1 className="font-display text-[32px] leading-none">Checkout</h1>
        <form onSubmit={handleSubmit} className="mt-8 space-y-8">
          <div className="bg-white border p-6">
            <h3 className="text-[11px] tracking-[0.2em] uppercase mb-6">Shipping Information</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <input required placeholder="Full Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="border px-4 py-3 text-[13px] outline-none focus:border-black" />
              <input required placeholder="Phone (WhatsApp)" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} className="border px-4 py-3 text-[13px] outline-none focus:border-black" />
              <input placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="border px-4 py-3 text-[13px] outline-none focus:border-black md:col-span-2" />
              <input required placeholder="Street Address" value={form.address} onChange={e=>setForm({...form,address:e.target.value})} className="border px-4 py-3 text-[13px] outline-none focus:border-black md:col-span-2" />
              <input required placeholder="City" value={form.city} onChange={e=>setForm({...form,city:e.target.value})} className="border px-4 py-3 text-[13px] outline-none focus:border-black" />
              <select value={form.province} onChange={e=>setForm({...form,province:e.target.value})} className="border px-4 py-3 text-[13px] outline-none focus:border-black">
                <option>Punjab</option><option>Sindh</option><option>KPK</option><option>Balochistan</option><option>Islamabad</option><option>GB / AJK</option>
              </select>
            </div>
          </div>

          <div className="bg-white border p-6">
            <h3 className="text-[11px] tracking-[0.2em] uppercase mb-6">Payment Method</h3>
            <div className="space-y-3">
              <label className={`flex items-center justify-between border p-4 cursor-pointer ${payment==='cod'?'border-black bg-black text-white':'hover:border-black'}`}>
                <div className="flex items-center gap-3"><input type="radio" checked={payment==='cod'} onChange={()=>setPayment('cod')} /><span className="text-[13px] tracking-wide uppercase">Cash On Delivery — COD Available</span></div>
                <span className="text-[11px] opacity-70">Pay on delivery</span>
              </label>
              <label className={`flex items-center justify-between border p-4 cursor-pointer ${payment==='whatsapp'?'border-[#25D366] bg-[#25D366] text-white':'hover:border-[#25D366]'}`}>
                <div className="flex items-center gap-3"><input type="radio" checked={payment==='whatsapp'} onChange={()=>setPayment('whatsapp')} /><span className="text-[13px] tracking-wide uppercase">WhatsApp Order</span></div>
                <span className="text-[11px] opacity-70">Chat & confirm</span>
              </label>
            </div>
          </div>

          <button type="submit" className="w-full bg-black text-white py-4 text-[11px] tracking-[0.2em] uppercase hover:bg-crown-gold transition-colors">Place Order — {formatPrice(total+shipping)}</button>
        </form>
      </div>

      <div className="bg-[#FCFBF9] border p-6 h-fit sticky top-28">
        <h3 className="font-display text-lg mb-6">Order Summary</h3>
        <div className="space-y-4">
          {items.map(i=>(
            <div key={i.product.id} className="flex gap-3"><img src={(i.product.images.find(img=>img.isMain)||i.product.images[0]).url} alt={i.product.name} className="w-12 h-14 object-cover bg-white" /><div className="flex-1"><div className="text-[12px] uppercase font-medium">{i.product.name}</div><div className="text-[11px] opacity-60">Qty: {i.quantity}</div></div><div className="text-[12px] font-semibold">{formatPrice(i.product.price*i.quantity)}</div></div>
          ))}
        </div>
        <div className="border-t mt-6 pt-4 space-y-2 text-[13px]">
          <div className="flex justify-between"><span className="opacity-60">Subtotal</span><span>{formatPrice(total)}</span></div>
          <div className="flex justify-between"><span className="opacity-60">Shipping</span><span>{shipping===0?'Free':formatPrice(shipping)}</span></div>
          <div className="flex justify-between font-semibold border-t pt-2"><span>Total</span><span>{formatPrice(total+shipping)}</span></div>
        </div>
      </div>
    </div>
  );
};

export const CheckoutSuccess = () => {
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get('order');
  return (
    <div className="max-w-[600px] mx-auto px-8 py-20 text-center">
      <div className="w-20 h-20 mx-auto bg-crown-gold text-white flex items-center justify-center text-3xl font-display mb-6">✓</div>
      <h1 className="font-display text-[36px] leading-none">Order Confirmed</h1>
      <p className="text-[13px] opacity-60 mt-4">Thank you for shopping with THE CROWN VAULT. Your order {orderId} is confirmed. COD available — our team will contact you on WhatsApp shortly.</p>
      <div className="mt-8 flex gap-3 justify-center">
        <Link to="/shop" className="bg-black text-white px-8 py-3 text-[11px] tracking-widest uppercase">Continue Shopping</Link>
        <a href={`https://wa.me/923001234567?text=Hello%20I%20placed%20order%20${orderId}`} target="_blank" rel="noopener noreferrer" className="border px-8 py-3 text-[11px] tracking-widest uppercase">Track via WhatsApp</a>
      </div>
    </div>
  );
};
