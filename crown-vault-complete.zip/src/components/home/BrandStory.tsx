export const BrandStory = () => {
  return (
    <section className="bg-[#0A0A0A] text-white relative overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-20 md:py-28 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="text-crown-gold text-[11px] tracking-[0.3em] uppercase mb-6">The Crown Vault — Luxury Curations</div>
          <h2 className="font-display text-[36px] md:text-[56px] leading-[0.95] tracking-tight">
            Perfume First.<br />
            <span className="text-white/50 font-light italic">Pakistan Market</span><br />
            Adaptation.
          </h2>
          <div className="mt-8 space-y-4 text-[13px] leading-7 text-white/60 font-light max-w-[480px]">
            <p>Inspired by your blueprint — fragrance, handbag schematic, timepiece layout, jewellery concept. We translate luxury schematics into shoppable reality.</p>
            <p>Soft window photography, matte black leather with polished gold hardware, highly polished gold with diamond dust — every detail considered for COD, WhatsApp order, and nationwide delivery.</p>
          </div>
          <div className="mt-10 grid grid-cols-3 gap-8 border-t border-white/10 pt-8 max-w-[480px]">
            <div>
              <div className="text-crown-gold font-display text-2xl">Light</div>
              <div className="text-[10px] tracking-widest uppercase opacity-50 mt-1">Product Photography — Soft Window</div>
            </div>
            <div>
              <div className="text-crown-gold font-display text-2xl">Macro</div>
              <div className="text-[10px] tracking-widest uppercase opacity-50 mt-1">Texture Shot • Couple Sets</div>
            </div>
            <div>
              <div className="text-crown-gold font-display text-2xl">Staging</div>
              <div className="text-[10px] tracking-widest uppercase opacity-50 mt-1">White Marble • Minimal Daily Wear</div>
            </div>
          </div>
        </div>
        <div className="relative">
          <div className="grid grid-cols-2 gap-[1px] bg-white/10 border border-white/10">
            <div className="bg-[#141414] p-6">
              <div className="text-[10px] tracking-widest uppercase opacity-40">01 Perfume</div>
              <div className="font-display text-lg mt-3 leading-tight">Signature Scent Positioning • Long-lasting Projection</div>
              <div className="flex gap-2 mt-6">
                <span className="w-6 h-6 rounded-full bg-[#C9A86A]"></span>
                <span className="w-6 h-6 rounded-full bg-[#F8F6F3]"></span>
                <span className="w-6 h-6 rounded-full bg-black border border-white/20"></span>
              </div>
            </div>
            <div className="bg-[#141414] p-6">
              <div className="text-[10px] tracking-widest uppercase opacity-40">02 Bags</div>
              <div className="font-display text-lg mt-3 leading-tight">Stitch Count per Inch • Handle Attachment Point</div>
              <div className="mt-6 inline-flex items-center gap-2 text-[10px] uppercase tracking-widest">
                <span className="w-4 h-4 rounded-full bg-black border border-white/20"></span> Matte Black Leather
              </div>
            </div>
            <div className="bg-[#141414] p-6">
              <div className="text-[10px] tracking-widest uppercase opacity-40">03 Watches</div>
              <div className="font-display text-lg mt-3 leading-tight">Chronograph Function • Automatic Rotor</div>
              <div className="mt-6 text-[10px] uppercase tracking-widest opacity-50">Brushed Stainless Steel • Black Dial</div>
            </div>
            <div className="bg-[#141414] p-6">
              <div className="text-[10px] tracking-widest uppercase opacity-40">04 Jewellery</div>
              <div className="font-display text-lg mt-3 leading-tight">Abstract Pendant • Fine Chain Gauge</div>
              <div className="mt-6 flex items-center gap-2 text-[10px] uppercase tracking-widest text-crown-gold">
                <span className="w-4 h-4 rounded-full bg-crown-gold"></span> Highly Polished Gold
              </div>
            </div>
          </div>
          <div className="absolute -bottom-6 -right-6 bg-crown-gold text-black p-6 hidden md:block">
            <div className="text-[10px] tracking-[0.2em] uppercase">Luxury Curation</div>
            <div className="font-display text-2xl mt-1">TcV Blueprint</div>
          </div>
        </div>
      </div>
    </section>
  );
};
