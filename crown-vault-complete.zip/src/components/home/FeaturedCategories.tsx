import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const cats = [
  {
    title: 'Perfume',
    desc: 'Signature Scent Positioning • Gift Box Integration',
    image: `/assets/products/${encodeURIComponent('WhatsApp Image 2026-07-17 at 8.30.52 PM (2).jpeg')}`,
    slug: 'perfume',
    count: '5 Scents',
    color: 'from-[#0A0A0A]/70 to-transparent',
  },
  {
    title: 'Bags',
    desc: 'Structured Office Totes • Evening Clutch Collection',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format',
    slug: 'bags',
    count: '12 Designs',
    color: 'from-[#0A0A0A]/60 to-transparent',
  },
  {
    title: 'Jewellery',
    desc: 'Highly Polished Gold • Diamond Dust Setting',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=800&auto=format',
    slug: 'jewellery',
    count: '8 Pieces',
    color: 'from-[#C9A86A]/80 to-transparent',
  },
];

export const FeaturedCategories = () => {
  return (
    <section className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-16 md:py-24">
      <div className="flex items-end justify-between mb-10">
        <div>
          <div className="text-[11px] tracking-[0.3em] uppercase opacity-50 mb-3">Curated Departments</div>
          <h2 className="font-display text-[30px] md:text-[42px] leading-none">Shop By Category</h2>
        </div>
        <Link to="/shop" className="hidden md:inline-flex text-[11px] tracking-[0.2em] uppercase border-b border-black pb-1 hover:text-crown-gold hover:border-crown-gold transition-colors">View All Collections</Link>
      </div>

      <div className="grid md:grid-cols-3 gap-[1px] bg-neutral-200 border border-neutral-200">
        {cats.map((c, i) => (
          <motion.div key={c.slug} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="relative group bg-white overflow-hidden aspect-[4/5] md:aspect-[4/5]">
            <img src={c.image} alt={c.title} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.5s]" />
            <div className={`absolute inset-0 bg-gradient-to-t ${c.color}`} />
            <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-end">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-white text-black text-[10px] tracking-widest px-3 py-1 uppercase">{c.count}</span>
                <span className="w-8 h-[1px] bg-white/60"></span>
              </div>
              <h3 className="font-display text-white text-[28px] tracking-wide uppercase">{c.title}</h3>
              <p className="text-white/70 text-[11px] mt-2 leading-5 max-w-[240px]">{c.desc}</p>
              <Link to={`/categories/${c.slug}`} className="mt-6 inline-flex bg-white text-black px-6 py-3 text-[11px] tracking-[0.2em] uppercase hover:bg-black hover:text-white transition-colors w-fit">
                Explore
              </Link>
            </div>
            <div className="absolute top-6 right-6 w-10 h-10 border border-white/30 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-lg">↗</span>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};
