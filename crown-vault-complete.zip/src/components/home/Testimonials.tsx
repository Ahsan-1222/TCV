const reviews = [
  { name: 'Ayesha M.', city: 'Lahore', text: 'ROOH AVANT is my signature now. Luxury packaging and WhatsApp order made it so easy. COD delivered in 2 days.', rating: 5 },
  { name: 'Bilal K.', city: 'Karachi', text: 'The Crown Vault team curated perfectly. GOLD extrait lasts entire wedding. Highly polished gold bottle looks premium.', rating: 5 },
  { name: 'Sana J.', city: 'Islamabad', text: 'Bought bags and perfume combo. Matte black tote stitch quality is exceptional. Will reorder.', rating: 5 },
];

export const Testimonials = () => {
  return (
    <section className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12 py-20">
      <div className="flex items-end justify-between mb-12">
        <h2 className="font-display text-[32px] leading-none">Client Chronicles</h2>
        <div className="hidden md:flex items-center gap-2 text-[11px] tracking-widest uppercase opacity-50">
          <span>★★★★★</span>
          <span>4.9/5 • 487 reviews</span>
        </div>
      </div>
      <div className="grid md:grid-cols-3 gap-[1px] bg-neutral-200 border border-neutral-200">
        {reviews.map(r => (
          <div key={r.name} className="bg-white p-8">
            <div className="flex gap-1 text-crown-gold text-sm">{'★★★★★'.slice(0, r.rating)}</div>
            <p className="font-display text-[17px] leading-7 mt-6">“{r.text}”</p>
            <div className="mt-6 flex items-center gap-3">
              <div className="w-10 h-10 bg-black text-white flex items-center justify-center font-display text-sm">{r.name[0]}</div>
              <div>
                <div className="text-[12px] tracking-wide font-medium">{r.name}</div>
                <div className="text-[11px] opacity-50 uppercase tracking-widest">{r.city}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
