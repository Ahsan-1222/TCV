import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-[#FCFBF9]">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-0 min-h-[640px] md:min-h-[720px] items-center">
          {/* Left Content */}
          <div className="lg:col-span-5 py-12 md:py-20 relative z-10">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="inline-flex items-center gap-2 border border-crown-gold/30 px-4 py-1.5 rounded-full mb-8">
              <span className="w-1.5 h-1.5 bg-crown-gold rounded-full animate-pulse"></span>
              <span className="text-[10px] tracking-[0.2em] uppercase">New Collection 2026 • ROOH Fragrances</span>
            </motion.div>

            <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.1 }} className="font-display text-[42px] md:text-[64px] lg:text-[72px] leading-[0.9] tracking-[-0.03em]">
              Luxury<br />
              <span className="text-crown-gold italic font-light">Curated for</span><br />
              Pakistan
            </motion.h1>

            <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="mt-6 text-[13px] md:text-[14px] leading-7 text-neutral-600 max-w-[380px] font-light">
              Discover our signature perfume collection — ROOH AQUA, AVANT, NOIR, GOLD & VELVET. Long-lasting projection, gift box integration, and polished gold hardware. COD available nationwide.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.3 }} className="mt-8 flex flex-wrap gap-3">
              <Link to="/shop" className="bg-black text-white px-8 py-4 text-[11px] tracking-[0.2em] uppercase hover:bg-crown-gold transition-colors duration-500">
                Explore Collection
              </Link>
              <Link to="/categories/perfume" className="border border-black px-8 py-4 text-[11px] tracking-[0.2em] uppercase hover:bg-black hover:text-white transition-colors duration-500">
                Perfumes
              </Link>
            </motion.div>

            <div className="mt-12 grid grid-cols-3 gap-6 max-w-[360px] border-t border-neutral-200 pt-6">
              <div>
                <div className="font-display text-2xl">5</div>
                <div className="text-[10px] tracking-widest uppercase opacity-60">Signature Scents</div>
              </div>
              <div>
                <div className="font-display text-2xl">10h+</div>
                <div className="text-[10px] tracking-widest uppercase opacity-60">Long Lasting</div>
              </div>
              <div>
                <div className="font-display text-2xl">COD</div>
                <div className="text-[10px] tracking-widest uppercase opacity-60">Nationwide</div>
              </div>
            </div>
          </div>

          {/* Right Visual — Marble + Product */}
          <div className="lg:col-span-7 relative h-[560px] md:h-[720px] bg-[#F8F6F3] overflow-hidden">
            <div className="absolute inset-0 marble-bg"></div>
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.2, ease: 'easeOut' }} className="absolute inset-0 flex items-center justify-center p-8">
              <div className="relative w-full max-w-[680px] aspect-[4/3] bg-white shadow-[0_40px_80px_-20px_rgba(0,0,0,0.15)] overflow-hidden">
                <img src={`/assets/products/${encodeURIComponent('WhatsApp Image 2026-07-17 at 8.30.52 PM (4).jpeg')}`} alt="ROOH Trio" className="w-full h-full object-cover" />
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent p-6 flex items-end justify-between">
                  <div className="text-white">
                    <div className="text-[10px] tracking-[0.2em] uppercase opacity-80">Featured</div>
                    <div className="font-display text-xl mt-1">ROOH Triad — AQUA • AVANT • NOIR</div>
                  </div>
                  <div className="text-white text-right">
                    <div className="text-[20px] font-display">Rs. 2,450</div>
                    <div className="text-[10px] uppercase tracking-widest opacity-60 line-through">Rs. 4,200</div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Blueprint Overlays */}
            <div className="absolute top-6 left-6 bg-white/80 backdrop-blur px-4 py-3 border border-black/5 hidden md:block">
              <div className="text-[9px] tracking-widest uppercase opacity-50">Fragrance Blueprint</div>
              <div className="font-display text-[12px] mt-1 leading-tight">Soft Window Photography<br />Gold • Clear Glass • Black</div>
            </div>
            <div className="absolute top-6 right-6 bg-black text-white px-4 py-3 hidden md:block">
              <div className="text-[9px] tracking-widest uppercase opacity-60">COD Available</div>
              <div className="text-[11px] tracking-widest uppercase mt-1">WhatsApp Order<br />Nationwide Delivery</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
