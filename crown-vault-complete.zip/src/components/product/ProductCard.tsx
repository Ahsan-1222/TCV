import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Eye } from 'lucide-react';
import type { Product } from '../../types';
import { formatPrice } from '../../lib/utils';
import { useWishlist } from '../../context/WishlistContext';
import { useCart } from '../../context/CartContext';

export const ProductCard = ({ product, index = 0 }: { product: Product; index?: number }) => {
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const { addToCart } = useCart();
  const inWishlist = isInWishlist(product.id);
  const mainImage = product.images.find(i => i.isMain) || product.images[0];
  const discount = product.comparePrice ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05, duration: 0.5 }}
      className="group relative bg-white"
    >
      {/* Image */}
      <div className="relative aspect-[4/5] overflow-hidden bg-[#F8F6F3]">
        {discount > 0 && (
          <div className="absolute top-3 left-3 z-10 bg-black text-white text-[10px] tracking-widest px-2.5 py-1">-{discount}%</div>
        )}
        {product.bestSeller && (
          <div className="absolute top-3 right-12 z-10 bg-crown-gold text-white text-[10px] tracking-widest px-2.5 py-1 uppercase">Best Seller</div>
        )}
        <Link to={`/product/${product.slug}`}>
          <img src={mainImage.url} alt={mainImage.alt} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s] ease-out" loading="lazy" />
        </Link>

        {/* Actions Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-500 flex gap-2">
          <button onClick={() => addToCart(product)} className="flex-1 bg-black text-white text-[11px] tracking-[0.18em] uppercase py-3 hover:bg-crown-gold transition-colors">
            Add to Cart
          </button>
          <Link to={`/product/${product.slug}`} className="w-11 h-11 bg-white flex items-center justify-center hover:bg-black hover:text-white transition-colors">
            <Eye size={16} />
          </Link>
        </div>

        <button
          onClick={() => (inWishlist ? removeFromWishlist(product.id) : addToWishlist(product))}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all ${inWishlist ? 'bg-crown-gold text-white' : 'bg-white/90 backdrop-blur hover:bg-black hover:text-white'}`}
        >
          <Heart size={14} fill={inWishlist ? 'white' : 'none'} />
        </button>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <Link to={`/product/${product.slug}`} className="block">
              <h3 className="font-display text-[14px] tracking-[0.06em] uppercase leading-tight hover:text-crown-gold transition-colors">{product.name}</h3>
            </Link>
            <p className="text-[11px] text-neutral-500 mt-1 line-clamp-1">{product.shortDescription}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-3">
          <span className="text-[13px] font-semibold">{formatPrice(product.price)}</span>
          {product.comparePrice && <span className="text-[11px] line-through opacity-40">{formatPrice(product.comparePrice)}</span>}
        </div>
        <div className="flex items-center gap-1 mt-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <span key={i} className={`w-2.5 h-2.5 ${i < Math.floor(product.rating) ? 'text-crown-gold' : 'text-neutral-200'}`}>★</span>
            ))}
          </div>
          <span className="text-[10px] opacity-50 ml-1">({product.reviewCount})</span>
        </div>
      </div>
    </motion.div>
  );
};
