import type { Product } from '../../types';
import { ProductCard } from './ProductCard';

export const ProductGrid = ({ products, title }: { products: Product[]; title?: string }) => {
  return (
    <div>
      {title && (
        <div className="flex items-end justify-between mb-8">
          <h2 className="font-display text-2xl md:text-[28px] tracking-wide">{title}</h2>
          <div className="h-[1px] flex-1 mx-8 bg-neutral-200 hidden md:block"></div>
        </div>
      )}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-[1px] bg-neutral-100 border border-neutral-100">
        {products.map((p, i) => (
          <ProductCard key={p.id} product={p} index={i} />
        ))}
      </div>
    </div>
  );
};
