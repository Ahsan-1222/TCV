// Firebase-ready structure stub
// In production, replace with actual Firebase SDK initialization

// Example expected env variables:
// VITE_FIREBASE_API_KEY, VITE_FIREBASE_AUTH_DOMAIN, etc.

export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "demo-key",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "thecrownvault-demo.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "thecrownvault-demo",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "thecrownvault-demo.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:123:web:abc",
};

// Firestore collections blueprint:
// - products: id, sku, name, slug, description, category, price, stock, images[], tags, featured, SEO metadata
// - orders: customer info, items, total, status, paymentMethod, COD flag
// - users: role admin/customer, wishlist
// - categories: name, slug, image
// - reviews: productId, rating, comment

export const collections = {
  products: "products",
  orders: "orders",
  users: "users",
  wishlists: "wishlists",
};

// Auth roles
export const ROLES = {
  admin: "admin",
  customer: "customer",
};

// Future integration point:
// import { initializeApp } from "firebase/app";
// import { getAuth } from "firebase/auth";
// import { getFirestore } from "firebase/firestore";
// import { getStorage } from "firebase/storage";
// const app = initializeApp(firebaseConfig);
// export const auth = getAuth(app);
// export const db = getFirestore(app);
// export const storage = getStorage(app);
